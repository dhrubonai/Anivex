__turbopack_load_page_chunks__("/search", [
  "static/chunks/0va2~i~e.~.pu.js",
  "static/chunks/0azrel.nlmonz.js",
  "static/chunks/0i6.ak~b61uv9.js",
  "static/chunks/0uzqp8a8de.k_.js",
  "static/chunks/0u1citcv2szfz.css",
  "static/chunks/turbopack-0h5v_36hiwd90.js"
])
