__turbopack_load_page_chunks__("/", [
  "static/chunks/0wtr12e-909un.js",
  "static/chunks/0azrel.nlmonz.js",
  "static/chunks/0i6.ak~b61uv9.js",
  "static/chunks/0uzqp8a8de.k_.js",
  "static/chunks/0u1citcv2szfz.css",
  "static/chunks/turbopack-0vqwxtmrdhdno.js"
])
