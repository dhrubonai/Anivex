__turbopack_load_page_chunks__("/creator", [
  "static/chunks/15sh3ppi-objd.js",
  "static/chunks/0uzqp8a8de.k_.js",
  "static/chunks/0i6.ak~b61uv9.js",
  "static/chunks/turbopack-0lhedit~ugu15.js"
])
