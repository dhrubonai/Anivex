__turbopack_load_page_chunks__("/_error", [
  "static/chunks/06.xr9zmyhn9f.js",
  "static/chunks/0uzqp8a8de.k_.js",
  "static/chunks/0i6.ak~b61uv9.js",
  "static/chunks/turbopack-0104s_g5mvfkw.js"
])
