__turbopack_load_page_chunks__("/_app", [
  "static/chunks/04v9oe92ij3bg.js",
  "static/chunks/14vhzqhprz6l_.js",
  "static/chunks/0i6.ak~b61uv9.js",
  "static/chunks/0uzqp8a8de.k_.js",
  "static/chunks/0u1citcv2szfz.css",
  "static/chunks/turbopack-0p5cbq2mphz~s.js"
])
