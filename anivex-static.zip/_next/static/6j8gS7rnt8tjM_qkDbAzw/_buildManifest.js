self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/0w6..0~nvh6e-.js"
  ],
  "/_error": [
    "static/chunks/0ip2jo7tajf8j.js"
  ],
  "/creator": [
    "static/chunks/0.oymqyimmbo-.js"
  ],
  "/search": [
    "static/chunks/0t5wykleoyswu.js"
  ],
  "/watch": [
    "static/chunks/0svavdlonsz1n.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/creator",
    "/search",
    "/watch"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()