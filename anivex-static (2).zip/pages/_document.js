import { Html, Head, Main, NextScript } from 'next/document';

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <meta name="description" content="Anivex - Free anime streaming with multi-language support" />
        <meta name="theme-color" content="#0a0a0a" />
        <meta property="og:title" content="Anivex - Free Anime Streaming" />
        <meta property="og:description" content="Watch anime for free. Multi-language support including Hindi, Bengali, English, Japanese." />
        <meta property="og:type" content="website" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
