import { useState, useEffect, useContext } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { AppContext } from './_app';
import { getTopAnime, getSeasonNow, getUpcomingAnime, getPopularAnime, getAnimeByGenre } from '@/lib/jikan';

// ====== Content Card Component ======
function ContentCard({ item }) {
  const title = item.title || item.name || 'Unknown';
  const rating = item.vote_average || item.score || 0;
  const poster = item.images?.jpg?.image_url;
  const watchUrl = `/watch?type=anime&id=${item.mal_id}&name=${encodeURIComponent(title)}`;

  return (
    <Link href={watchUrl} className="content-card anime-card">
      {poster ? (
        <img className="card-poster" src={poster} alt={title} loading="lazy" style={{ height: '240px', aspectRatio: 'auto' }} />
      ) : (
        <div className="placeholder-poster">{title}</div>
      )}
      <div className="card-overlay">
        <div className="card-title">{title}</div>
        {rating > 0 && <div className="card-rating">⭐ {typeof rating === 'number' ? rating.toFixed(1) : rating}</div>}
      </div>
    </Link>
  );
}

// ====== Content Row Component ======
function ContentRow({ title, items }) {
  if (!items || items.length === 0) return null;

  return (
    <div className="content-section">
      <div className="section-header">
        <h2 className="section-title">{title}</h2>
      </div>
      <div className="content-row">
        {items.map((item) => (
          <ContentCard
            key={item.id || item.mal_id}
            item={item}
          />
        ))}
      </div>
    </div>
  );
}

// ====== Anime Hero Component ======
function AnimeHero({ items }) {
  const router = useRouter();
  const [heroItem, setHeroItem] = useState(null);

  useEffect(() => {
    if (items && items.length > 0) {
      setHeroItem(items[Math.floor(Math.random() * Math.min(5, items.length))]);
    }
  }, [items]);

  if (!heroItem) return null;

  const title = heroItem.title || 'Unknown';
  const poster = heroItem.images?.jpg?.large_image_url || heroItem.images?.jpg?.image_url;
  const rating = heroItem.score || 'N/A';
  const year = heroItem.year || '';
  const episodes = heroItem.episodes || 0;

  const handlePlay = () => {
    router.push(`/watch?type=anime&id=${heroItem.mal_id}&name=${encodeURIComponent(title)}`);
  };

  return (
    <div className="hero" style={{ height: '75vh', maxHeight: '700px' }}>
      {poster && <div className="hero-backdrop" style={{ backgroundImage: `url(${poster})` }} />}
      <div className="hero-content">
        <h1 className="hero-title">{title}</h1>
        <div className="hero-meta">
          {rating && <span className="rating">⭐ {rating}</span>}
          {year && <span>{year}</span>}
          {episodes > 0 && <span>{episodes} Episodes</span>}
          {heroItem.seasons > 0 && <span>{heroItem.seasons} Season{heroItem.seasons > 1 ? 's' : ''}</span>}
        </div>
        <div className="hero-genres">
          {heroItem.genres?.slice(0, 4).map((g) => (
            <span key={g.mal_id || g.name} className="genre-tag">{g.name}</span>
          ))}
        </div>
        <p className="hero-desc">{heroItem.synopsis}</p>
        <div className="hero-actions">
          <button className="btn-play" onClick={handlePlay}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
            Play Now
          </button>
          <button className="btn-info" onClick={handlePlay}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="16" x2="12" y2="12" />
              <line x1="12" y1="8" x2="12.01" y2="8" />
            </svg>
            More Info
          </button>
        </div>
      </div>
    </div>
  );
}

// ====== Main Home Page ======
export default function Home() {
  const { lang } = useContext(AppContext);
  const [data, setData] = useState({
    topAnime: [],
    seasonNow: [],
    upcomingAnime: [],
    popularAnime: [],
    actionAnime: [],
    romanceAnime: [],
    comedyAnime: [],
    fantasyAnime: [],
  });
  const [loading, setLoading] = useState(true);

  // Fetch all anime data
  useEffect(() => {
    let cancelled = false;

    async function fetchData() {
      setLoading(true);
      try {
        const [
          topAnimeData,
          seasonNowData,
          upcomingAnimeData,
          popularAnimeData,
          actionAnimeData,
          romanceAnimeData,
          comedyAnimeData,
          fantasyAnimeData,
        ] = await Promise.all([
          getTopAnime(1, 20),
          getSeasonNow(1, 20),
          getUpcomingAnime(1, 20),
          getPopularAnime(1, 20),
          getAnimeByGenre(1, 20),   // Action
          getAnimeByGenre(22, 20),  // Romance
          getAnimeByGenre(4, 20),   // Comedy
          getAnimeByGenre(10, 20),  // Fantasy
        ]);

        if (!cancelled) {
          setData({
            topAnime: topAnimeData?.data || [],
            seasonNow: seasonNowData?.data || [],
            upcomingAnime: upcomingAnimeData?.data || [],
            popularAnime: popularAnimeData?.data || [],
            actionAnime: actionAnimeData?.data || [],
            romanceAnime: romanceAnimeData?.data || [],
            comedyAnime: comedyAnimeData?.data || [],
            fantasyAnime: fantasyAnimeData?.data || [],
          });
        }
      } catch (err) {
        console.error('Failed to fetch data:', err);
      }
      if (!cancelled) setLoading(false);
    }

    fetchData();
    return () => { cancelled = true; };
  }, [lang]);

  if (loading) {
    return (
      <div className="page-enter">
        <div className="loading-container" style={{ minHeight: '60vh' }}>
          <div className="spinner" />
        </div>
      </div>
    );
  }

  return (
    <div className="page-enter">
      {/* Hero Banner */}
      {data.seasonNow.length > 0 && <AnimeHero items={data.seasonNow} />}

      {/* Content Rows */}
      <ContentRow title="Airing This Season" items={data.seasonNow} />
      <ContentRow title="Top Anime" items={data.topAnime} />
      <ContentRow title="Most Popular" items={data.popularAnime} />
      <ContentRow title="Action" items={data.actionAnime} />
      <ContentRow title="Fantasy" items={data.fantasyAnime} />
      <ContentRow title="Romance" items={data.romanceAnime} />
      <ContentRow title="Comedy" items={data.comedyAnime} />
      <ContentRow title="Upcoming" items={data.upcomingAnime} />
    </div>
  );
}
