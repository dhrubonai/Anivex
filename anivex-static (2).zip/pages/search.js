import { useState, useEffect, useContext } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Link from 'next/link';
import { AppContext } from './_app';
import { searchAnime } from '@/lib/jikan';

export default function Search() {
  const router = useRouter();
  const { lang } = useContext(AppContext);
  const { q } = router.query;

  const [query, setQuery] = useState('');
  const [animeResults, setAnimeResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  // Read query from URL on mount
  useEffect(() => {
    if (q) {
      setQuery(decodeURIComponent(q));
    }
  }, [q]);

  // Perform search
  useEffect(() => {
    if (!query.trim()) {
      setAnimeResults([]);
      setSearched(false);
      return;
    }

    const debounce = setTimeout(async () => {
      setLoading(true);
      setSearched(true);
      try {
        const jikanData = await searchAnime(query, 1, 25);
        if (jikanData?.data) {
          setAnimeResults(jikanData.data);
        }
      } catch (err) {
        console.error('Search error:', err);
      }
      setLoading(false);
    }, 500);

    return () => clearTimeout(debounce);
  }, [query, lang]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) {
      router.push(`/search?q=${encodeURIComponent(query.trim())}`, undefined, { shallow: true });
    }
  };

  return (
    <div className="search-page page-enter">
      <Head>
        <title>{query ? `Search: ${query} - Anivex` : 'Search - Anivex'}</title>
      </Head>

      {/* Search Bar */}
      <div style={{ padding: '0 2rem 1.5rem' }}>
        <form onSubmit={handleSearch} style={{ display: 'flex', gap: '0.75rem', maxWidth: '700px' }}>
          <div style={{
            flex: 1, display: 'flex', alignItems: 'center', gap: '0.75rem',
            background: 'var(--bg-card)', border: '1px solid var(--border)',
            borderRadius: 'var(--radius-lg)', padding: '0.75rem 1.25rem',
          }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--text-muted)', flexShrink: 0 }}>
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              placeholder="Search anime..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={{
                flex: 1, background: 'none', border: 'none', color: 'var(--text-primary)',
                fontSize: '1rem', outline: 'none', fontFamily: 'inherit',
              }}
            />
          </div>
          <button
            type="submit"
            style={{
              padding: '0.75rem 1.5rem', background: 'var(--accent)', color: 'white',
              borderRadius: 'var(--radius-lg)', fontWeight: 700, fontSize: '0.9rem',
              transition: 'var(--transition)',
            }}
          >
            Search
          </button>
        </form>
      </div>

      {/* Query Display */}
      {searched && query && (
        <div className="search-page-query">
          Results for <span>&quot;{query}&quot;</span>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="loading-container">
          <div className="spinner" />
        </div>
      )}

      {/* Anime Results from Jikan */}
      {!loading && searched && animeResults.length > 0 && (
        <div className="content-section">
          <div className="section-header">
            <h2 className="section-title">Anime</h2>
          </div>
          <div className="search-grid" style={{ display: 'grid', padding: '0 2rem 1rem' }}>
            {animeResults.map((anime) => (
              <Link
                key={anime.mal_id}
                href={`/watch?type=anime&id=${anime.mal_id}&name=${encodeURIComponent(anime.title)}`}
                className="content-card anime-card"
                style={{ flex: 'none' }}
              >
                {anime.images?.jpg?.image_url ? (
                  <img className="card-poster" src={anime.images.jpg.image_url} alt={anime.title} loading="lazy" style={{ height: '240px', aspectRatio: 'auto' }} />
                ) : (
                  <div className="placeholder-poster">{anime.title}</div>
                )}
                <div className="card-overlay">
                  <div className="card-title">{anime.title}</div>
                  {anime.score > 0 && <div className="card-rating">⭐ {anime.score}</div>}
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* No Results */}
      {!loading && searched && animeResults.length === 0 && (
        <div style={{ textAlign: 'center', padding: '4rem 2rem', color: 'var(--text-muted)' }}>
          <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ margin: '0 auto 1rem', display: 'block', color: 'var(--text-muted)' }}>
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <p style={{ fontSize: '1.2rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>
            No results found
          </p>
          <p>Try searching for something else</p>
        </div>
      )}

      {/* Initial State */}
      {!searched && (
        <div style={{ textAlign: 'center', padding: '4rem 2rem', color: 'var(--text-muted)' }}>
          <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ margin: '0 auto 1.5rem', display: 'block', color: 'var(--text-muted)', opacity: 0.5 }}>
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <p style={{ fontSize: '1.3rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>
            Search for anime
          </p>
          <p>Type in the search box above to find anime</p>
        </div>
      )}
    </div>
  );
}
