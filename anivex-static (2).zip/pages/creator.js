import Head from 'next/head';

export default function Creator() {
  return (
    <div className="creator-page page-enter">
      <Head>
        <title>Creator - Anivex</title>
      </Head>

      {/* Hero Section */}
      <div className="creator-hero">
        <div className="creator-profile">
          <img
            className="creator-avatar"
            src="https://i.ibb.co/hRSzrw2N/file-69.jpg"
            alt="Mohiuddin Abdul Kadir Dhrubo"
          />
          <h1 className="creator-name">Mohiuddin Abdul Kadir Dhrubo</h1>
          <p className="creator-role">Developer & Creator</p>
          <p className="creator-bio">
            Creator of Anivex.
          </p>
        </div>
      </div>

      {/* Details Section */}
      <div className="creator-details">
        {/* About */}
        <div className="creator-section">
          <h2 className="creator-section-title">About</h2>
          <p style={{ color: 'var(--text-secondary)', lineHeight: 1.8, fontSize: '0.95rem' }}>
            Hi! I&apos;m Mohiuddin Abdul Kadir Dhrubo, the developer behind Anivex.
          </p>
        </div>

        {/* Contact & Social */}
        <div className="creator-section">
          <h2 className="creator-section-title">Contact & Social</h2>
          <div className="social-links">
            {/* Gmail */}
            <a
              href="mailto:dhrubomohiuddinabdulkadir@gmail.com"
              className="social-link"
              target="_blank"
              rel="noopener noreferrer"
            >
              <div className="social-icon gmail">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                  <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                </svg>
              </div>
              <div>
                <div className="social-label">Gmail</div>
                <div className="social-handle">dhrubomohiuddinabdulkadir@gmail.com</div>
              </div>
            </a>

            {/* Facebook */}
            <a
              href="https://www.facebook.com/share/1LLhAmRUp2/"
              className="social-link"
              target="_blank"
              rel="noopener noreferrer"
            >
              <div className="social-icon facebook">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </div>
              <div>
                <div className="social-label">Facebook</div>
                <div className="social-handle">Dhrubo Morse</div>
              </div>
            </a>

            {/* Instagram */}
            <a
              href="https://www.instagram.com/dhrubo_morse?igsh=aHNsazZyOTY4dWN2"
              className="social-link"
              target="_blank"
              rel="noopener noreferrer"
            >
              <div className="social-icon instagram">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                </svg>
              </div>
              <div>
                <div className="social-label">Instagram</div>
                <div className="social-handle">@dhrubo_morse</div>
              </div>
            </a>
          </div>
        </div>


      </div>
    </div>
  );
}
