import { useState, useEffect, useContext } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Link from 'next/link';
import { AppContext } from './_app';
import { getAnimeDetails } from '@/lib/jikan';
import { findAnitakuSlug, getEpisodeServers, titleToSlug } from '@/lib/anitaku';
import { SERVER_TYPES, organizeServers } from '@/lib/servers';

export default function Watch() {
  const router = useRouter();
  const { lang } = useContext(AppContext);
  const { type, id, name } = router.query;

  // States
  const [animeDetails, setAnimeDetails] = useState(null);
  const [anitakuSlug, setAnitakuSlug] = useState(null);
  const [organizedServers, setOrganizedServers] = useState([]);
  const [serverUrl, setServerUrl] = useState('');
  const [iframeKey, setIframeKey] = useState(0);

  const [activeTab, setActiveTab] = useState('hsub');
  const [activeServerIndex, setActiveServerIndex] = useState(0);
  const [episode, setEpisode] = useState(1);

  const [totalEpisodes, setTotalEpisodes] = useState(24);
  const [hasDub, setHasDub] = useState(false);

  // Loading states
  const [status, setStatus] = useState('loading'); // 'loading' | 'playing' | 'error'
  const [retryCount, setRetryCount] = useState(0);
  const [loadTime, setLoadTime] = useState(0);

  const malId = type === 'anime' ? id : null;

  // Step 1: Fetch anime details from Jikan
  useEffect(() => {
    if (type === 'anime' && id) {
      getAnimeDetails(id).then(data => {
        if (data?.data) {
          setAnimeDetails(data.data);
          if (data.data.episodes) setTotalEpisodes(data.data.episodes);
        }
      }).catch(() => {});
    }
  }, [type, id]);

  // Step 2: Resolve slug instantly from title
  useEffect(() => {
    if (type !== 'anime' || !name) return;
    const nameStr = decodeURIComponent(name);
    const titleForSearch = animeDetails?.title_english || animeDetails?.title || nameStr;
    const slug = titleToSlug(titleForSearch);
    if (slug) setAnitakuSlug(slug);
  }, [type, name, animeDetails?.title_english, animeDetails?.title]);

  // Step 3: Fetch video URLs via Netlify Function (FAST - no CORS proxy!)
  useEffect(() => {
    if (!anitakuSlug) return;

    let cancelled = false;
    setStatus('loading');
    setServerUrl('');
    setOrganizedServers([]);
    const startTime = Date.now();

    async function fetchVideo() {
      try {
        const data = await getEpisodeServers(anitakuSlug, episode);
        if (cancelled) return;

        const elapsed = Date.now() - startTime;
        setLoadTime(elapsed);

        if (data) {
          setHasDub(data.hasDub || data.servers?.dub?.length > 0);

          const organized = organizeServers(data.servers);
          setOrganizedServers(organized);

          if (organized.length > 0) {
            // Prefer embeddable servers (vibeplayer.site works in iframes)
            const embeddableServer = organized.find(s => s.embeddable);
            // Then prefer vibeplayer specifically
            const vibeServer = organized.find(s => s.url?.includes('vibeplayer'));
            // Then first available
            const bestServer = embeddableServer || vibeServer || organized[0];

            setActiveTab(bestServer.type);
            setActiveServerIndex(organized.indexOf(bestServer));
            setServerUrl(bestServer.url);
            setStatus('playing');
            setIframeKey(prev => prev + 1);
          } else {
            setStatus('error');
          }
        } else {
          setStatus('error');
        }
      } catch (err) {
        if (!cancelled) setStatus('error');
      }
    }

    fetchVideo();
    return () => { cancelled = true; };
  }, [anitakuSlug, episode, retryCount]);

  // Server/tab switching
  const currentTabServers = organizedServers.filter(s => s.type === activeTab);
  const availableTabs = [];
  if (organizedServers.some(s => s.type === 'hsub')) availableTabs.push('hsub');
  if (organizedServers.some(s => s.type === 'sub')) availableTabs.push('sub');
  if (organizedServers.some(s => s.type === 'dub')) availableTabs.push('dub');

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    const tabServers = organizedServers.filter(s => s.type === tab);
    if (tabServers.length > 0) {
      // Prefer embeddable server in this tab
      const embeddable = tabServers.find(s => s.embeddable);
      const best = embeddable || tabServers[0];
      setActiveServerIndex(tabServers.indexOf(best));
      setServerUrl(best.url);
      setIframeKey(prev => prev + 1);
    }
  };

  const handleServerChange = (index) => {
    const tabServers = organizedServers.filter(s => s.type === activeTab);
    if (tabServers[index]) {
      setActiveServerIndex(index);
      setServerUrl(tabServers[index].url);
      setIframeKey(prev => prev + 1);
    }
  };

  const handleEpisodeChange = (epNum) => {
    setEpisode(epNum);
    setActiveServerIndex(0);
    setIframeKey(prev => prev + 1);
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
  };

  const getTitle = () => animeDetails?.title || (name ? decodeURIComponent(name) : '');
  const getOverview = () => animeDetails?.synopsis || '';
  const getRating = () => animeDetails?.score || 'N/A';
  const getYear = () => animeDetails?.year || '';
  const getGenres = () => animeDetails?.genres?.map(g => g.name) || [];

  const title = getTitle();

  return (
    <div className="watch-page page-enter">
      <Head>
        <title>{title ? `${title} - Anivex` : 'Watch - Anivex'}</title>
      </Head>

      {/* Video Player - ONLY clean video player embeds */}
      <div className="player-section">
        <div className="player-wrapper">
          {status === 'playing' && serverUrl ? (
            <div className="player-container">
              <iframe
                key={iframeKey}
                className="player-iframe"
                src={serverUrl}
                sandbox="allow-scripts allow-same-origin allow-presentation"
                allowFullScreen
                allow="fullscreen; autoplay; encrypted-media; picture-in-picture"
                referrerPolicy="no-referrer"
                title={title}
              />
            </div>
          ) : status === 'loading' ? (
            <div style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              width: '100%', height: '100%', background: '#000', color: '#888',
              fontSize: '1rem', gap: '1rem'
            }}>
              <div className="spinner" />
              <span>Loading video source...</span>
              <span style={{ fontSize: '0.75rem', color: '#555' }}>
                Connecting to anime server...
              </span>
            </div>
          ) : (
            <div style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              width: '100%', height: '100%', background: '#000', color: '#888',
              fontSize: '1rem', gap: '1rem'
            }}>
              <span style={{ fontSize: '2rem' }}>&#9888;</span>
              <span>Could not load video</span>
              <span style={{ fontSize: '0.75rem', color: '#555', textAlign: 'center', maxWidth: '400px' }}>
                The anime server is temporarily unavailable. Please try again or try a different episode.
              </span>
              <button
                onClick={handleRetry}
                style={{
                  marginTop: '0.5rem', padding: '0.6rem 1.5rem', background: 'var(--accent)',
                  color: '#fff', border: 'none', borderRadius: '8px', fontSize: '0.9rem',
                  fontWeight: 600, cursor: 'pointer'
                }}
              >
                Retry
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Server Type Tabs */}
      {organizedServers.length > 0 && (
        <div className="server-bar" style={{ gap: '0.5rem', padding: '0.75rem 1.5rem' }}>
          <span className="server-bar-label">Type:</span>
          {availableTabs.map(tabId => {
            const tabConfig = SERVER_TYPES[tabId];
            const isActive = activeTab === tabId;
            return (
              <button
                key={tabId}
                className={`server-btn ${isActive ? 'active' : ''}`}
                onClick={() => handleTabChange(tabId)}
                style={isActive ? { borderColor: tabConfig.labelColor, background: tabConfig.labelColor + '22' } : {}}
              >
                {tabConfig.name}
                <span style={{
                  marginLeft: '6px', fontSize: '0.65rem', padding: '1px 5px',
                  borderRadius: '3px', background: tabConfig.labelColor,
                  color: '#fff', fontWeight: 700, verticalAlign: 'middle'
                }}>{tabConfig.label}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Server Selection */}
      {currentTabServers.length > 0 && (
        <div className="server-bar" style={{ gap: '0.5rem', padding: '0.5rem 1.5rem', borderTop: '1px solid var(--bg-card)' }}>
          <span className="server-bar-label">Server:</span>
          {currentTabServers.map((server, index) => (
            <button
              key={server.id}
              className={`server-btn ${activeServerIndex === index ? 'active' : ''}`}
              onClick={() => handleServerChange(index)}
            >
              {server.name}
            </button>
          ))}
        </div>
      )}

      {/* Episode Selector */}
      {type === 'anime' && (
        <div className="watch-info">
          <div className="season-episode-selector">
            <div className="episode-grid">
              {Array.from({ length: Math.min(totalEpisodes, 100) }, (_, i) => i + 1).map((ep) => (
                <div
                  key={ep}
                  className={`episode-card ${episode === ep ? 'active' : ''}`}
                  onClick={() => handleEpisodeChange(ep)}
                >
                  <div className="episode-num">Episode {ep}</div>
                  <div className="episode-name">EP {ep}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Anime Details */}
      <div className="watch-info">
        {!animeDetails ? (
          <div className="loading-container"><div className="spinner" /></div>
        ) : (
          <>
            <div className="watch-title-row">
              <h1 className="watch-title">{title}</h1>
            </div>

            <div className="watch-meta">
              <span className="rating">&#9733; {getRating()}</span>
              <span>{getYear()}</span>
              {animeDetails?.episodes && <span>{animeDetails.episodes} Episodes</span>}
              {animeDetails?.status && <span>{animeDetails.status}</span>}
              {animeDetails?.season && <span>{animeDetails.season}</span>}
              {hasDub && <span style={{ color: '#e50914', fontWeight: 600 }}>DUB Available</span>}
            </div>

            <div className="watch-genres">
              {getGenres().map((genre, i) => (
                <span key={i} className="genre-tag">{genre}</span>
              ))}
            </div>

            <p className="watch-overview">{getOverview()}</p>

            {animeDetails?.studios?.length > 0 && (
              <div style={{ marginTop: '0.5rem' }}>
                <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Studio: </span>
                {animeDetails.studios.map((s, i) => (
                  <span key={s.mal_id} style={{ color: 'var(--accent)', fontSize: '0.85rem' }}>
                    {s.name}{i < animeDetails.studios.length - 1 ? ', ' : ''}
                  </span>
                ))}
              </div>
            )}

            <div style={{ marginTop: '0.5rem', display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              {animeDetails?.source && (
                <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Source: {animeDetails.source}</span>
              )}
              {animeDetails?.rating && (
                <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Rating: {animeDetails.rating}</span>
              )}
            </div>

            {animeDetails?.relations?.length > 0 && (
              <div className="similar-section" style={{ marginTop: '1.5rem' }}>
                <h3 className="similar-section-title">Related</h3>
                <div className="similar-row">
                  {animeDetails.relations.slice(0, 10).map((rel, i) => {
                    const entry = rel.entry?.[0];
                    if (!entry) return null;
                    const relTitle = entry.name || 'Unknown';
                    return (
                      <Link
                        key={i}
                        href={`/watch?type=anime&id=${entry.mal_id}&name=${encodeURIComponent(relTitle)}`}
                        className="content-card"
                        style={{ flex: '0 0 140px' }}
                      >
                        <div className="placeholder-poster" style={{ background: 'var(--bg-card)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0.5rem', textAlign: 'center' }}>
                          {relTitle}
                        </div>
                        <div className="card-overlay">
                          <div className="card-title">{relTitle}</div>
                          <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{rel.relation}</div>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
