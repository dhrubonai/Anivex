import '@/styles/globals.css';
import Head from 'next/head';
import { useState, useEffect, createContext, useContext, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { searchAnime } from '@/lib/jikan';

// ====== Context ======
export const AppContext = createContext();

// ====== SVG Logo ======
function AnivexLogo() {
  return (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <rect width="32" height="32" rx="6" fill="#e50914"/>
      <path d="M7 8h3v16H7V8zm5 0h3l5 10V8h3v16h-3L15 14v10h-3V8z" fill="white"/>
    </svg>
  );
}

// ====== Navbar ======
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const { lang, changeLang, setSearchOpen } = useContext(AppContext);
  const router = useRouter();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const isActive = (path) => {
    if (path === '/') return router.pathname === '/';
    return router.pathname === path;
  };

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <Link href="/" className="nav-logo">
        <AnivexLogo />
        <span>ANIVEX</span>
      </Link>

      <div className="nav-links">
        <Link href="/" className={`nav-link ${isActive('/') ? 'active' : ''}`}>Home</Link>
        <Link href="/?tab=anime" className="nav-link">Anime</Link>
        <Link href="/creator" className={`nav-link ${isActive('/creator') ? 'active' : ''}`}>Creator</Link>
      </div>

      <div className="nav-actions">
        <button className="search-btn" onClick={() => setSearchOpen(true)} aria-label="Search">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </button>
        <select
          className="lang-selector"
          value={lang}
          onChange={(e) => changeLang(e.target.value)}
        >
          <option value="en">EN</option>
          <option value="hi">हिन्दी</option>
          <option value="bn">বাংলা</option>
          <option value="ja">日本語</option>
          <option value="ko">한국어</option>
          <option value="es">Español</option>
        </select>
      </div>
    </nav>
  );
}

// ====== Search Modal ======
function SearchModal() {
  const { setSearchOpen } = useContext(AppContext);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [animeResults, setAnimeResults] = useState([]);
  const inputRef = useRef(null);
  const router = useRouter();
  const debounceRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape') setSearchOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [setSearchOpen]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!query.trim()) {
      setAnimeResults([]);
      return;
    }

    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const jikanData = await searchAnime(query, 1, 10);
        if (jikanData?.data) {
          setAnimeResults(jikanData.data.slice(0, 10));
        }
      } catch (err) {
        console.error('Search error:', err);
      }
      setLoading(false);
    }, 400);
  }, [query]);

  const handleAnimeSelect = (anime) => {
    setSearchOpen(false);
    router.push(`/watch?type=anime&id=${anime.mal_id}&name=${encodeURIComponent(anime.title)}`);
  };



  return (
    <div className="search-overlay" onClick={() => setSearchOpen(false)}>
      <div className="search-modal" onClick={(e) => e.stopPropagation()}>
        <div className="search-input-wrap">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            ref={inputRef}
            className="search-input"
            type="text"
            placeholder="Search anime..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button className="search-close" onClick={() => setSearchOpen(false)}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        <div className="search-results">
          {loading && (
            <div className="search-loading">
              <div className="spinner" />
            </div>
          )}

          {!loading && query && animeResults.length === 0 && (
            <div className="search-empty">No results found for &quot;{query}&quot;</div>
          )}

          {animeResults.length > 0 && (
            <>
              <div style={{ padding: '0.5rem 0.75rem', color: 'var(--accent)', fontWeight: 700, fontSize: '0.85rem' }}>
                Anime
              </div>
              {animeResults.map((anime) => (
                <div key={anime.mal_id} className="search-result-item" onClick={() => handleAnimeSelect(anime)}>
                  <img
                    className="search-result-poster"
                    src={anime.images?.jpg?.image_url}
                    alt={anime.title}
                  />
                  <div className="search-result-info">
                    <div className="search-result-title">{anime.title}</div>
                    <div className="search-result-meta">
                      Anime &bull; {anime.year || 'N/A'} &bull; {anime.score ? `\u2B50 ${anime.score}` : 'N/A'}
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}


        </div>
      </div>
    </div>
  );
}

// ====== Footer ======
function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-brand">
          <h3>ANIVEX</h3>
          <p>Watch anime in multiple languages.</p>
        </div>
        <div className="footer-links">
          <h4>Navigation</h4>
          <Link href="/">Home</Link>
          <Link href="/search">Search</Link>
          <Link href="/creator">Creator</Link>
        </div>
        <div className="footer-links">
          <h4>Languages</h4>
          <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.5rem' }}>English</span>
          <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.5rem' }}>Hindi / हिन्दी</span>
          <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.5rem' }}>Bengali / বাংলা</span>
          <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.5rem' }}>Japanese / 日本語</span>
        </div>
      </div>
      <div className="footer-bottom">
        &copy; {new Date().getFullYear()} Anivex
      </div>
    </footer>
  );
}

// ====== Mobile Nav ======
function MobileNav() {
  const { setSearchOpen } = useContext(AppContext);
  const router = useRouter();

  const isActive = (path) => {
    if (path === '/') return router.pathname === '/';
    return router.pathname === path;
  };

  return (
    <div className="mobile-nav">
      <div className="mobile-nav-items">
        <Link href="/" className={`mobile-nav-item ${isActive('/') ? 'active' : ''}`}>
          <span className="mobile-nav-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
          </span>
          Home
        </Link>
        <Link href="/search" className={`mobile-nav-item ${isActive('/search') ? 'active' : ''}`}>
          <span className="mobile-nav-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          </span>
          Search
        </Link>
        <Link href="/creator" className={`mobile-nav-item ${isActive('/creator') ? 'active' : ''}`}>
          <span className="mobile-nav-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          </span>
          Creator
        </Link>
      </div>
    </div>
  );
}

// ====== Main App ======
export default function App({ Component, pageProps }) {
  const [lang, setLang] = useState('en');
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('anivex-lang');
    if (saved) setLang(saved);
  }, []);

  // Block popup/tab-under ads from video player iframes
  useEffect(() => {
    const originalOpen = window.open;
    window.open = function(url, target, features) {
      // Block all popup attempts from iframes
      if (url && typeof url === 'string') {
        // Allow same-origin navigation (our own site)
        try {
          const parsed = new URL(url, window.location.origin);
          if (parsed.origin === window.location.origin) {
            return originalOpen.call(window, url, target, features);
          }
        } catch {}
      }
      return null;
    };

    // Block beforeunload from ads trying to redirect
    const blockUnload = (e) => {
      // Only allow navigation from our own UI
      if (e.target && e.target.tagName !== 'A') {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', blockUnload);

    return () => {
      window.open = originalOpen;
      window.removeEventListener('beforeunload', blockUnload);
    };
  }, []);

  const changeLang = (newLang) => {
    setLang(newLang);
    localStorage.setItem('anivex-lang', newLang);
  };

  return (
    <AppContext.Provider value={{ lang, changeLang, searchOpen, setSearchOpen }}>
      <Head>
        <title>Anivex - Free Anime Streaming</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <Navbar />
      {searchOpen && <SearchModal />}
      <main style={{ paddingTop: '64px' }}>
        <Component {...pageProps} />
      </main>
      <Footer />
      <MobileNav />
    </AppContext.Provider>
  );
}
